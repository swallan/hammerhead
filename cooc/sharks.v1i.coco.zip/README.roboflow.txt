
sharks - v1 2022-02-18 11:02am
==============================

This dataset was exported via roboflow.ai on February 18, 2022 at 7:03 PM GMT

It includes 127 images.
Hammerhead are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 128x128 (Stretch)

No image augmentation techniques were applied.


